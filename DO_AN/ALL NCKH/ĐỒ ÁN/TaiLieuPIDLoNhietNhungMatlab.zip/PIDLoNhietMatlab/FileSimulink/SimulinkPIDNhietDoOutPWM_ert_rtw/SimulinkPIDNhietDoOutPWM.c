/*
 * File: SimulinkPIDNhietDoOutPWM.c
 *
 * Code generated for Simulink model 'SimulinkPIDNhietDoOutPWM'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Wed May 19 15:40:20 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SimulinkPIDNhietDoOutPWM.h"
#include "SimulinkPIDNhietDoOutPWM_private.h"
#include "SimulinkPIDNhietDoOutPWM_dt.h"

/* Block signals (default storage) */
B_SimulinkPIDNhietDoOutPWM_T SimulinkPIDNhietDoOutPWM_B;

/* Block states (default storage) */
DW_SimulinkPIDNhietDoOutPWM_T SimulinkPIDNhietDoOutPWM_DW;

/* Real-time model */
RT_MODEL_SimulinkPIDNhietDoOu_T SimulinkPIDNhietDoOutPWM_M_;
RT_MODEL_SimulinkPIDNhietDoOu_T *const SimulinkPIDNhietDoOutPWM_M =
  &SimulinkPIDNhietDoOutPWM_M_;

/* Forward declaration for local functions */
static void matlabCodegenHandle_matlabCod_h(codertarget_arduinobase_int_h_T *obj);
static void SimulinkPIDN_SystemCore_release(const
  codertarget_arduinobase_inter_T *obj);
static void SimulinkPIDNh_SystemCore_delete(const
  codertarget_arduinobase_inter_T *obj);
static void matlabCodegenHandle_matlabCodeg(codertarget_arduinobase_inter_T *obj);
static void arduino_AnalogInput_set_pinNumb(codertarget_arduinobase_int_h_T *obj,
  e_codertarget_arduinobase_i_h_T *iobj_0);
static void arduino_PWMOutput_set_pinNumber(codertarget_arduinobase_inter_T *obj,
  e_codertarget_arduinobase_int_T *iobj_0);
static void rate_monotonic_scheduler(void);

/*
 * Set which subrates need to run this base step (base rate always runs).
 * This function must be called prior to calling the model step function
 * in order to "remember" which rates need to run this base step.  The
 * buffering of events allows for overlapping preemption.
 */
void SimulinkPIDNhietDoOutPWM_SetEventsForThisBaseStep(boolean_T *eventFlags)
{
  /* Task runs when its counter is zero, computed via rtmStepTask macro */
  eventFlags[1] = ((boolean_T)rtmStepTask(SimulinkPIDNhietDoOutPWM_M, 1));
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 0 shares data with slower tid rate: 1 */
  SimulinkPIDNhietDoOutPWM_M->Timing.RateInteraction.TID0_1 =
    (SimulinkPIDNhietDoOutPWM_M->Timing.TaskCounters.TID[1] == 0);

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (SimulinkPIDNhietDoOutPWM_M->Timing.TaskCounters.TID[1])++;
  if ((SimulinkPIDNhietDoOutPWM_M->Timing.TaskCounters.TID[1]) > 99) {/* Sample time: [1.0s, 0.0s] */
    SimulinkPIDNhietDoOutPWM_M->Timing.TaskCounters.TID[1] = 0;
  }
}

static void matlabCodegenHandle_matlabCod_h(codertarget_arduinobase_int_h_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
  }
}

static void SimulinkPIDN_SystemCore_release(const
  codertarget_arduinobase_inter_T *obj)
{
  if ((obj->isInitialized == 1L) && obj->isSetupComplete) {
    MW_PWM_SetDutyCycle(obj->MW_PWM_HANDLE, 0);
  }
}

static void SimulinkPIDNh_SystemCore_delete(const
  codertarget_arduinobase_inter_T *obj)
{
  SimulinkPIDN_SystemCore_release(obj);
}

static void matlabCodegenHandle_matlabCodeg(codertarget_arduinobase_inter_T *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    SimulinkPIDNh_SystemCore_delete(obj);
  }
}

static void arduino_AnalogInput_set_pinNumb(codertarget_arduinobase_int_h_T *obj,
  e_codertarget_arduinobase_i_h_T *iobj_0)
{
  iobj_0->AvailablePwmPinNames.f1 = '2';
  iobj_0->AvailablePwmPinNames.f2 = '3';
  iobj_0->AvailablePwmPinNames.f3 = '4';
  iobj_0->AvailablePwmPinNames.f4 = '5';
  iobj_0->AvailablePwmPinNames.f5 = '6';
  iobj_0->AvailablePwmPinNames.f6 = '7';
  iobj_0->AvailablePwmPinNames.f7 = '8';
  iobj_0->AvailablePwmPinNames.f8 = '9';
  iobj_0->AvailablePwmPinNames.f9[0] = '1';
  iobj_0->AvailablePwmPinNames.f9[1] = '0';
  iobj_0->AvailablePwmPinNames.f10[0] = '1';
  iobj_0->AvailablePwmPinNames.f10[1] = '1';
  iobj_0->AvailablePwmPinNames.f11[0] = '1';
  iobj_0->AvailablePwmPinNames.f11[1] = '2';
  iobj_0->AvailablePwmPinNames.f12[0] = '1';
  iobj_0->AvailablePwmPinNames.f12[1] = '3';
  obj->Hw = iobj_0;
}

static void arduino_PWMOutput_set_pinNumber(codertarget_arduinobase_inter_T *obj,
  e_codertarget_arduinobase_int_T *iobj_0)
{
  iobj_0->AvailablePwmPinNames.f1 = '2';
  iobj_0->AvailablePwmPinNames.f2 = '3';
  iobj_0->AvailablePwmPinNames.f3 = '4';
  iobj_0->AvailablePwmPinNames.f4 = '5';
  iobj_0->AvailablePwmPinNames.f5 = '6';
  iobj_0->AvailablePwmPinNames.f6 = '7';
  iobj_0->AvailablePwmPinNames.f7 = '8';
  iobj_0->AvailablePwmPinNames.f8 = '9';
  iobj_0->AvailablePwmPinNames.f9[0] = '1';
  iobj_0->AvailablePwmPinNames.f9[1] = '0';
  iobj_0->AvailablePwmPinNames.f10[0] = '1';
  iobj_0->AvailablePwmPinNames.f10[1] = '1';
  iobj_0->AvailablePwmPinNames.f11[0] = '1';
  iobj_0->AvailablePwmPinNames.f11[1] = '2';
  iobj_0->AvailablePwmPinNames.f12[0] = '1';
  iobj_0->AvailablePwmPinNames.f12[1] = '3';
  obj->Hw = iobj_0;
}

/* Model step function for TID0 */
void SimulinkPIDNhietDoOutPWM_step0(void) /* Sample time: [0.01s, 0.0s] */
{
  real_T rtb_Sum;
  real_T rtb_FilterCoefficient;
  real_T u0;

  {                                    /* Sample time: [0.01s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* RateTransition: '<Root>/TmpRTBAtSumOutport1' */
  if (SimulinkPIDNhietDoOutPWM_M->Timing.RateInteraction.TID0_1) {
    SimulinkPIDNhietDoOutPWM_B.TmpRTBAtSumOutport1 =
      SimulinkPIDNhietDoOutPWM_DW.TmpRTBAtSumOutport1_Buffer0;
  }

  /* End of RateTransition: '<Root>/TmpRTBAtSumOutport1' */

  /* Gain: '<S35>/Filter Coefficient' incorporates:
   *  DiscreteIntegrator: '<S27>/Filter'
   *  Gain: '<S26>/Derivative Gain'
   *  Sum: '<S27>/SumD'
   */
  rtb_FilterCoefficient = (SimulinkPIDNhietDoOutPWM_P.PIDController_D *
    SimulinkPIDNhietDoOutPWM_B.TmpRTBAtSumOutport1 -
    SimulinkPIDNhietDoOutPWM_DW.Filter_DSTATE) *
    SimulinkPIDNhietDoOutPWM_P.PIDController_N;

  /* Sum: '<S41>/Sum' incorporates:
   *  DiscreteIntegrator: '<S32>/Integrator'
   *  Gain: '<S37>/Proportional Gain'
   */
  rtb_Sum = (SimulinkPIDNhietDoOutPWM_P.PIDController_P *
             SimulinkPIDNhietDoOutPWM_B.TmpRTBAtSumOutport1 +
             SimulinkPIDNhietDoOutPWM_DW.Integrator_DSTATE) +
    rtb_FilterCoefficient;

  /* Saturate: '<S39>/Saturation' */
  if (rtb_Sum > SimulinkPIDNhietDoOutPWM_P.PIDController_UpperSaturationLi) {
    SimulinkPIDNhietDoOutPWM_B.Saturation =
      SimulinkPIDNhietDoOutPWM_P.PIDController_UpperSaturationLi;
  } else if (rtb_Sum <
             SimulinkPIDNhietDoOutPWM_P.PIDController_LowerSaturationLi) {
    SimulinkPIDNhietDoOutPWM_B.Saturation =
      SimulinkPIDNhietDoOutPWM_P.PIDController_LowerSaturationLi;
  } else {
    SimulinkPIDNhietDoOutPWM_B.Saturation = rtb_Sum;
  }

  /* End of Saturate: '<S39>/Saturation' */

  /* MATLABSystem: '<Root>/PWM' */
  if (SimulinkPIDNhietDoOutPWM_B.Saturation < 255.0) {
    u0 = SimulinkPIDNhietDoOutPWM_B.Saturation;
  } else {
    u0 = 255.0;
  }

  if (!(u0 > 0.0)) {
    u0 = 0.0;
  }

  MW_PWM_SetDutyCycle(SimulinkPIDNhietDoOutPWM_DW.obj_b.MW_PWM_HANDLE, u0);

  /* End of MATLABSystem: '<Root>/PWM' */

  /* Update for DiscreteIntegrator: '<S32>/Integrator' incorporates:
   *  Gain: '<S25>/Kb'
   *  Gain: '<S29>/Integral Gain'
   *  Sum: '<S25>/SumI2'
   *  Sum: '<S25>/SumI4'
   */
  SimulinkPIDNhietDoOutPWM_DW.Integrator_DSTATE +=
    ((SimulinkPIDNhietDoOutPWM_B.Saturation - rtb_Sum) *
     SimulinkPIDNhietDoOutPWM_P.PIDController_Kb +
     SimulinkPIDNhietDoOutPWM_P.PIDController_I *
     SimulinkPIDNhietDoOutPWM_B.TmpRTBAtSumOutport1) *
    SimulinkPIDNhietDoOutPWM_P.Integrator_gainval;

  /* Update for DiscreteIntegrator: '<S27>/Filter' */
  SimulinkPIDNhietDoOutPWM_DW.Filter_DSTATE +=
    SimulinkPIDNhietDoOutPWM_P.Filter_gainval * rtb_FilterCoefficient;

  /* External mode */
  rtExtModeUploadCheckTrigger(2);
  rtExtModeUpload(0, (real_T)SimulinkPIDNhietDoOutPWM_M->Timing.taskTime0);

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.01s, 0.0s] */
    if ((rtmGetTFinal(SimulinkPIDNhietDoOutPWM_M)!=-1) &&
        !((rtmGetTFinal(SimulinkPIDNhietDoOutPWM_M)-
           SimulinkPIDNhietDoOutPWM_M->Timing.taskTime0) >
          SimulinkPIDNhietDoOutPWM_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(SimulinkPIDNhietDoOutPWM_M, "Simulation finished");
    }

    if (rtmGetStopRequested(SimulinkPIDNhietDoOutPWM_M)) {
      rtmSetErrorStatus(SimulinkPIDNhietDoOutPWM_M, "Simulation finished");
    }
  }

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   */
  SimulinkPIDNhietDoOutPWM_M->Timing.taskTime0 =
    (++SimulinkPIDNhietDoOutPWM_M->Timing.clockTick0) *
    SimulinkPIDNhietDoOutPWM_M->Timing.stepSize0;
}

/* Model step function for TID1 */
void SimulinkPIDNhietDoOutPWM_step1(void) /* Sample time: [1.0s, 0.0s] */
{
  uint16_T rtb_AnalogInput_0;
  real_T rtb_Sum;

  /* MATLABSystem: '<Root>/Analog Input' */
  if (SimulinkPIDNhietDoOutPWM_DW.obj.SampleTime !=
      SimulinkPIDNhietDoOutPWM_P.AnalogInput_SampleTime) {
    SimulinkPIDNhietDoOutPWM_DW.obj.SampleTime =
      SimulinkPIDNhietDoOutPWM_P.AnalogInput_SampleTime;
  }

  MW_AnalogIn_Start(SimulinkPIDNhietDoOutPWM_DW.obj.MW_ANALOGIN_HANDLE);
  MW_AnalogInSingle_ReadResult
    (SimulinkPIDNhietDoOutPWM_DW.obj.MW_ANALOGIN_HANDLE, &rtb_AnalogInput_0, 3);

  /* Fcn: '<S2>/Fcn' incorporates:
   *  DataTypeConversion: '<S2>/Data Type Conversion'
   *  MATLABSystem: '<Root>/Analog Input'
   */
  SimulinkPIDNhietDoOutPWM_B.Fcn = (real_T)rtb_AnalogInput_0 * 5.0 / 1023.0 *
    100.0;

  /* Constant: '<Root>/Constant' */
  SimulinkPIDNhietDoOutPWM_B.Constant =
    SimulinkPIDNhietDoOutPWM_P.Constant_Value;

  /* Sum: '<Root>/Sum' */
  rtb_Sum = SimulinkPIDNhietDoOutPWM_B.Constant - SimulinkPIDNhietDoOutPWM_B.Fcn;

  /* Update for RateTransition: '<Root>/TmpRTBAtSumOutport1' */
  SimulinkPIDNhietDoOutPWM_DW.TmpRTBAtSumOutport1_Buffer0 = rtb_Sum;
  rtExtModeUpload(1, (real_T)((SimulinkPIDNhietDoOutPWM_M->Timing.clockTick1) *
    1.0));

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The resolution of this integer timer is 1.0, which is the step size
   * of the task. Size of "clockTick1" ensures timer will not overflow during the
   * application lifespan selected.
   */
  SimulinkPIDNhietDoOutPWM_M->Timing.clockTick1++;
}

/* Model initialize function */
void SimulinkPIDNhietDoOutPWM_initialize(void)
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)SimulinkPIDNhietDoOutPWM_M, 0,
                sizeof(RT_MODEL_SimulinkPIDNhietDoOu_T));
  rtmSetTFinal(SimulinkPIDNhietDoOutPWM_M, 300.0);
  SimulinkPIDNhietDoOutPWM_M->Timing.stepSize0 = 0.01;

  /* External mode info */
  SimulinkPIDNhietDoOutPWM_M->Sizes.checksums[0] = (3564843244U);
  SimulinkPIDNhietDoOutPWM_M->Sizes.checksums[1] = (3586120577U);
  SimulinkPIDNhietDoOutPWM_M->Sizes.checksums[2] = (1264452221U);
  SimulinkPIDNhietDoOutPWM_M->Sizes.checksums[3] = (3389851479U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[3];
    SimulinkPIDNhietDoOutPWM_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    systemRan[1] = &rtAlwaysEnabled;
    systemRan[2] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(SimulinkPIDNhietDoOutPWM_M->extModeInfo,
      &SimulinkPIDNhietDoOutPWM_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(SimulinkPIDNhietDoOutPWM_M->extModeInfo,
                        SimulinkPIDNhietDoOutPWM_M->Sizes.checksums);
    rteiSetTPtr(SimulinkPIDNhietDoOutPWM_M->extModeInfo, rtmGetTPtr
                (SimulinkPIDNhietDoOutPWM_M));
  }

  /* block I/O */
  (void) memset(((void *) &SimulinkPIDNhietDoOutPWM_B), 0,
                sizeof(B_SimulinkPIDNhietDoOutPWM_T));

  /* states (dwork) */
  (void) memset((void *)&SimulinkPIDNhietDoOutPWM_DW, 0,
                sizeof(DW_SimulinkPIDNhietDoOutPWM_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    SimulinkPIDNhietDoOutPWM_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 18;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  {
    codertarget_arduinobase_int_h_T *obj;
    MW_AnalogIn_TriggerSource_Type trigger_val;
    codertarget_arduinobase_inter_T *obj_0;

    /* Start for MATLABSystem: '<Root>/Analog Input' */
    SimulinkPIDNhietDoOutPWM_DW.obj.matlabCodegenIsDeleted = true;
    SimulinkPIDNhietDoOutPWM_DW.obj.isInitialized = 0L;
    SimulinkPIDNhietDoOutPWM_DW.obj.SampleTime = -1.0;
    SimulinkPIDNhietDoOutPWM_DW.obj.matlabCodegenIsDeleted = false;
    arduino_AnalogInput_set_pinNumb(&SimulinkPIDNhietDoOutPWM_DW.obj,
      &SimulinkPIDNhietDoOutPWM_DW.gobj_0);
    SimulinkPIDNhietDoOutPWM_DW.obj.SampleTime =
      SimulinkPIDNhietDoOutPWM_P.AnalogInput_SampleTime;
    obj = &SimulinkPIDNhietDoOutPWM_DW.obj;
    SimulinkPIDNhietDoOutPWM_DW.obj.isSetupComplete = false;
    SimulinkPIDNhietDoOutPWM_DW.obj.isInitialized = 1L;
    obj->MW_ANALOGIN_HANDLE = MW_AnalogInSingle_Open(0UL);
    trigger_val = MW_ANALOGIN_SOFTWARE_TRIGGER;
    MW_AnalogIn_SetTriggerSource
      (SimulinkPIDNhietDoOutPWM_DW.obj.MW_ANALOGIN_HANDLE, trigger_val, 0UL);
    SimulinkPIDNhietDoOutPWM_DW.obj.isSetupComplete = true;

    /* Start for RateTransition: '<Root>/TmpRTBAtSumOutport1' */
    SimulinkPIDNhietDoOutPWM_B.TmpRTBAtSumOutport1 =
      SimulinkPIDNhietDoOutPWM_P.TmpRTBAtSumOutport1_InitialCond;

    /* Start for MATLABSystem: '<Root>/PWM' */
    SimulinkPIDNhietDoOutPWM_DW.obj_b.matlabCodegenIsDeleted = true;
    SimulinkPIDNhietDoOutPWM_DW.obj_b.isInitialized = 0L;
    SimulinkPIDNhietDoOutPWM_DW.obj_b.matlabCodegenIsDeleted = false;
    arduino_PWMOutput_set_pinNumber(&SimulinkPIDNhietDoOutPWM_DW.obj_b,
      &SimulinkPIDNhietDoOutPWM_DW.gobj_0_g);
    obj_0 = &SimulinkPIDNhietDoOutPWM_DW.obj_b;
    SimulinkPIDNhietDoOutPWM_DW.obj_b.isSetupComplete = false;
    SimulinkPIDNhietDoOutPWM_DW.obj_b.isInitialized = 1L;
    obj_0->MW_PWM_HANDLE = MW_PWM_Open(5UL, 0.0, 0.0);
    MW_PWM_Start(SimulinkPIDNhietDoOutPWM_DW.obj_b.MW_PWM_HANDLE);
    SimulinkPIDNhietDoOutPWM_DW.obj_b.isSetupComplete = true;

    /* InitializeConditions for DiscreteIntegrator: '<S32>/Integrator' */
    SimulinkPIDNhietDoOutPWM_DW.Integrator_DSTATE =
      SimulinkPIDNhietDoOutPWM_P.PIDController_InitialConditio_e;

    /* InitializeConditions for RateTransition: '<Root>/TmpRTBAtSumOutport1' */
    SimulinkPIDNhietDoOutPWM_DW.TmpRTBAtSumOutport1_Buffer0 =
      SimulinkPIDNhietDoOutPWM_P.TmpRTBAtSumOutport1_InitialCond;

    /* InitializeConditions for DiscreteIntegrator: '<S27>/Filter' */
    SimulinkPIDNhietDoOutPWM_DW.Filter_DSTATE =
      SimulinkPIDNhietDoOutPWM_P.PIDController_InitialConditionF;
  }
}

/* Model terminate function */
void SimulinkPIDNhietDoOutPWM_terminate(void)
{
  /* Terminate for MATLABSystem: '<Root>/Analog Input' */
  matlabCodegenHandle_matlabCod_h(&SimulinkPIDNhietDoOutPWM_DW.obj);

  /* Terminate for MATLABSystem: '<Root>/PWM' */
  matlabCodegenHandle_matlabCodeg(&SimulinkPIDNhietDoOutPWM_DW.obj_b);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
