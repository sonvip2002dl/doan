
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'project' 
 * Target:  'V2M-MPS2' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "CMSDK_CM7_SP.h"

#define RTE_FINSH_USING_MSH
#define RTE_USING_DEVICE

#endif /* RTE_COMPONENTS_H */
