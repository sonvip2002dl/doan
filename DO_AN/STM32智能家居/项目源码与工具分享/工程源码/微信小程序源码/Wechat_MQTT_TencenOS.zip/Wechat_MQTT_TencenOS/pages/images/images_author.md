LED灯图标：
作者：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=1995

temp图标：
作者：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=184782

humd图标：
作者：https://www.iconfont.cn/user/detail?spm=a313x.7781069.0.d214f71f6&uid=123585