package myself.mqtt.wenzheng.studio.mqtt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class antenna extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_antenna);
    }
}
