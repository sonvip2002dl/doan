
//index.js
import mqtt from './../../utils/mqtt.js';
//获取应用实例
const app = getApp();
const host = 'wxs://www.ferkl.cn/mqtt';
Page({
  data: {
    client: null,
    options: {
      protocolVersion: 4,     //MQTT连接协议版本
      clientId: randomString(10),   //保证ID唯一   或者用随机数生成 //randomString(10)
      clean: false,
      username: '1v1r5ep/wenzheng',
      password: 'tNVKODyl2chbm5yp',
      reconnectPeriod: 1000, //
      connectTimeout: 30*1000, //
      resubscribe: true // 如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认true）
    },
    topic: { 
      HumdTopic: '11KVANS7VO/STM32/ZX_event',
      LEDcontrolTopic: '11KVANS7VO/STM32/ZX_control'
    },
    value: {
      Humdlogo: './../images/humd.png',
      HumdValue: 0,
      Templogo: './../images/temp.png',
      TempValue: 0,
      light_logo:'./../images/light.png',
      G_value:0,
      PM25_logo: './../images/pm25.png',
      PM25_value:0,
      wind_logo: './../images/wind.png',
      F_value:0,
    },
    LEDValue: [{
      LEDlogo: './../images/lock_open.png',
      ButtonValue: '开灯',
      ButtonFlag: true,
    }]
  },

  onClick_connect: function () {
    var that = this;
    this.data.client = mqtt.connect(host, this.data.options);
    that.data.client.on('connect', that.ConnectCallback);
    that.data.client.on("message", that.MessageProcess);
    that.data.client.on("error", that.ConnectError);
    that.data.client.on("reconnect", that.ClientReconnect);
    that.data.client.on("offline", that.ClientOffline);
    wx.showToast({
      title: '连接中...'
    })
  },
  onClick_disconnect: function() {
    var that = this;
    that.data.client.end();
    wx.showToast({
      title: '断开连接'
    })
  },
  onLoad: function() {   //软件开始时运行（生命周期比较特殊）
    wx.setNavigationBarTitle({
      title: 'MQTT_DEMO'
    })
  },

  onShow: function() {
    console.log("on show");
  },

  onHide: function() {
     var that = this;
     console.log("on hide");
     that.data.client.end();  //每次隐藏都关闭MQTT
  },

  onUnload: function() {
    var that = this;
    console.log("on unload");
    that.data.client.end();   //退出关闭MQTT
  },

  LedControl: function(e) {
    var that = this;
    wx.vibrateShort();
    if (that.data.LEDValue[0].ButtonFlag) {
      that.setData({
        'LEDValue[0].ButtonValue': '关灯',
        'LEDValue[0].ButtonFlag': false,
        "LEDValue[0].LEDlogo": './../images/lock_open.png',
      })
      that.data.client.publish(that.data.topic.LEDcontrolTopic, "open", {
        qos: 1
      });
    } else {
      that.setData({
        'LEDValue[0].ButtonValue': '开灯',
        'LEDValue[0].ButtonFlag': true,
        "LEDValue[0].LEDlogo": './../images/lock_close.png',
      })
      that.data.client.publish(that.data.topic.LEDcontrolTopic, "open", {
        qos: 1
      });
    }
  },

  MessageProcess: function(topic, payload) {
    var that = this;
    var payload_string = payload.toString();
    console.log(topic);
    if (topic == that.data.topic.HumdTopic) {
      var msg_payload = payload_string.match(/(\S*)}/)[1];
      msg_payload +="}"
      console.log(payload_string + "数据类型为：" + typeof (payload_string) + "长度：" + payload_string.length);
      //var test_buffer = '{"temperature":26.9,"humidity":48.7,"light":2.0,"PM25":54.0,"wind_speed":0.0,"door":"close"}';
      //var jsonObj = JSON.parse(test_buffer.toString());
      //console.log(jsonObj);
      var jsonObj = JSON.parse(msg_payload);
      //var jsonObj = JSON.stringify(payload_string)
      console.log(jsonObj.door);
      that.setData({  
        'value.HumdValue': jsonObj.humidity,
        'value.TempValue': jsonObj.temperature, 
        'value.PM25_value': jsonObj.PM25,
        'value.G_value': jsonObj.light,
        'value.F_value': jsonObj.wind_speed
      })
    }

  },

  ConnectCallback: function(connack) {
    var that = this;
    console.log("连接成功");
    that.data.client.subscribe(that.data.topic.HumdTopic, function (err, granted) {
      if (!err) {
        wx.showToast({
          title: '订阅主题成功',
          icon: 'none',
          duration: 4000
        })
      } else {
        console.log("订阅主题失败")
      }
    });
  },
  ConnectError: function(error) {
    console.log(" 服务器 error 的回调" + error)
  },

  ClientReconnect: function() {
    console.log(" 服务器 reconnect的回调")
  },

  ClientOffline: function() {
    console.log(" 服务器offline的回调")
  },



})
function randomString(len) {
  len = len || 32;
  var $chars = 'ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678';
  var maxPos = $chars.length;
  var pwd = '';
  for (let i = 0; i < len; i++) {
    pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
  }
  return pwd;
}