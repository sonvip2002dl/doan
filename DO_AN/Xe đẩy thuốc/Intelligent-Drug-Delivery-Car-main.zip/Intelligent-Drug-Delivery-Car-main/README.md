# 21年电赛控制题“智能送药小车”完整代码开源
21年电赛控制题“智能送药小车”完整代码开源, 基于STM32HAL库的主控代码（包含一车、二车），电机控制使用位置速度串级PID控制，数字识别采用OpenMV的模板匹配(Openmv3就可实现功能)，三路灰度传感器巡线。以及包含按键和OLED组成的简易菜单功能。 效果展示及视频教程进B站，链接如下 https://www.bilibili.com/video/BV1UL411V7XK?p=2&amp;amp;share_source=copy_web
