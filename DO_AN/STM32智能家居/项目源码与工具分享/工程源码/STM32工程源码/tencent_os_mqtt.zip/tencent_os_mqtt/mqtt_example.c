#include "esp8266.h"
#include "mcu_init.h"
#include "usart.h"
#include "mqtt_wrapper.h"
#include "mqtt_config.h"
#include "cmsis_os.h"
#include "oled.h"
#include "CRC.h"
#define USE_ESP8266

uint8_t MX_485_flag = 0;
#define TASK1_STK_SIZE		2048
void mqtt_demo(void *arg);
osThreadDef(mqtt_demo, osPriorityNormal, 1, TASK1_STK_SIZE);
#define TASK2_STK_SIZE		1024
void my_Task(void *arg);
osThreadDef(my_Task, osPriorityAboveNormal, 1, TASK2_STK_SIZE);

k_sem_t test_sem_01;
float H_val = 0;
float T_val = 0;
float L_val = 0;
float P_val = 0;
float W_val = 0;
float Z_val = 0;
char door_flag[6] = {0};
float GET_485(unsigned char * hex,int back_len,int msg_bit,int wait);


void mqtt_demo(void *arg)
{
    k_err_t err;
    int count = 1;
    int sock_id = 0;
    char cont[16];
    unsigned char read_data[40];
    int read_len;
    char topic[30];
    char buffer[110];
    mqtt_con_param_t con_param;
    con_param.keep_alive_interval = 2000;
    con_param.cleansession = 1;
    con_param.username = MQTT_USR_NAME;
    con_param.password = MQTT_PASSWORD;
    con_param.client_id = MQTT_CLIENT_ID;
    mqtt_pub_param_t pub_param;
    pub_param.dup = 0;
    pub_param.qos = 0;
    pub_param.retained = 0;
    pub_param.id = 0;
    pub_param.topic = MQTT_PUBLISH_TOPIC;
    mqtt_sub_param_t sub_param;
    sub_param.count = 1;
    sub_param.dup = 0;
    sub_param.id = 1;
    sub_param.req_qos = 0;
    sub_param.topic = MQTT_SUBSCRIBE_TOPIC;
#ifdef USE_ESP8266
    esp8266_sal_init(HAL_UART_PORT_0);
    esp8266_join_ap("CMCC-wenzheng", "wenzhengspace666");
#endif

#ifdef USE_NB_BC35
    int bc35_28_95_sal_init(hal_uart_port_t uart_port);
    bc35_28_95_sal_init(HAL_UART_PORT_0);
#endif
    sock_id = tos_mqtt_connect(MQTT_SERVER_IP, MQTT_SERVER_PORT, &con_param);
    printf("socket id: %d\r\n",sock_id);
    if (tos_mqtt_subscribe(sock_id, &sub_param) != 0) {
        printf("subscribe failed!!!\n");
    }
    while (1) {
        printf("MQTT count: %d\r\n",count);
        read_len = tos_mqtt_receive(topic, sizeof(topic), read_data, sizeof(read_data));
        if (read_len >= 0) {
            printf("---------->topic: %s, payload: %s, payload_len: %d\n", topic, read_data, read_len);
            if(strstr((char*)read_data, "open")) {
                HAL_GPIO_WritePin(Door_GPIO_Port, Door_Pin, GPIO_PIN_SET);
                osDelay(1000);
                HAL_GPIO_WritePin(Door_GPIO_Port, Door_Pin, GPIO_PIN_RESET);
            }

        }
        count++;
        err = tos_sem_pend(&test_sem_01, TOS_TIME_FOREVER);  //��ȡ�ź��� һֱ�ȴ�
        if (err != K_ERR_NONE) {    //������ɹ�
            printf("sem_error!!\r\n");
            continue;             //��ִ������Ĵ���  ���ٷ�������
        }
        memset(buffer, 0, sizeof(buffer));
        snprintf(buffer, sizeof(buffer), "{\"temperature\":%3.1f,\"humidity\":%3.1f,\"light\":%3.1f,\"PM25\":%3.1f,\"wind_speed\":%3.1f,\"door\":\"%s\"}",
                 T_val/10,H_val/10,L_val,P_val,W_val,door_flag);
        printf("\r\npublish_buffer:%s\r\n",buffer);
        pub_param.topic = MQTT_PUBLISH_TOPIC;
        pub_param.payload = (unsigned char *)buffer;
        pub_param.payload_len = sizeof(buffer);
        if (tos_mqtt_publish(sock_id, &pub_param) != 0) {
            printf("publish failed!!!\n");
        } else {
            printf("\r\npublish topic success!!!\r\n");

        }
        memset(buffer, 0, sizeof(buffer));
        memset(cont, 0, sizeof(cont));
        sprintf(cont,"485 Test:%d",count);
        OLED_ShowString(2,2,(uint8_t*)cont,16);
    }
}

void my_Task(void *arg)
{
    k_err_t err;
    extern uint8_t aRxBuffer3[100];
    unsigned char  hexdata_1[8]   =  {0x01,0x03,0x00,0x08,0x00,0x01,0x05,0xC8};  //������
    unsigned char  hexdata_1_1[8] =  {0x01,0x03,0x00,0x00,0x00,0x02,0xC4,0x0B};  //��ʪ��
    unsigned char  hexdata_2[8]   =  {0x02,0x03,0x00,0x01,0x00,0x14,0x14,0x36};  //PM2.5
    unsigned char  hexdata_3[8]   =  {0x03,0x03,0x00,0x00,0x00,0x01,0x85,0xE8};  //������
    unsigned char  hexdata_4[8]   =  {0x04,0x03,0x00,0x02,0x00,0x02,0x65,0x9E};  //���ն�
    HAL_UART_Receive_IT(&huart3,aRxBuffer3,7);               //ʹ�ܴ��ڽ����ж�
    while(1) {
        HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_SET);
        Z_val = GET_485(hexdata_1,7,3,200);
        T_val = GET_485(hexdata_1_1,9,5,200);  //�¶�
        H_val = GET_485(hexdata_1_1,9,3,200);  //ʪ��
        P_val = GET_485(hexdata_2,45,17,200);
        W_val = GET_485(hexdata_3,7,3,200);
        L_val = GET_485(hexdata_4,9,5,200);
        sprintf(door_flag,"%s","close");
        printf("ALL:%f,W:%f",P_val,W_val);
        HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
        err = tos_sem_post(&test_sem_01);  //�ͷ��ź���
        osDelay(1000);
    }
}
float GET_485(unsigned char * hex,int back_len,int msg_bit,int wait)
{
    float OUT_val =0;
    HAL_UART_Receive_IT(&huart3,aRxBuffer3,back_len);               //ʹ�ܴ��ڽ����ж�
    HAL_UART_Transmit_IT(&huart3 ,hex,8);                           //������ѯ485�豸
    HAL_UART_Transmit_IT(&huart3 ,"\r\n",2);                        //���ڷ�������
    osDelay(500);
    if(MX_485_flag == 1) {
        MX_485_flag = 0;
		//CRCУ��	
        if((crc16tablefast(aRxBuffer3,back_len-2)&0xff) == aRxBuffer3[back_len-2]&&(((crc16tablefast(aRxBuffer3,back_len-2)>>8)&0xff) == aRxBuffer3[back_len-1]))
        {
			printf("CRC_success...\r\n");
            OUT_val = (aRxBuffer3[msg_bit]<<8)+aRxBuffer3[msg_bit+1];
        }
        else {
			printf("CRC_error...\r\n");
            OUT_val = 0;
        }
        memset(aRxBuffer3, 0, sizeof(aRxBuffer3));
        return  OUT_val;
    } else {
        memset(aRxBuffer3, 0, sizeof(aRxBuffer3)); //���buffer
        return  0;
    }
}
void application_entry(void *arg)
{
    osThreadCreate(osThread(mqtt_demo), NULL); // Create task1
    osThreadCreate(osThread(my_Task), NULL); // Create task2
}

