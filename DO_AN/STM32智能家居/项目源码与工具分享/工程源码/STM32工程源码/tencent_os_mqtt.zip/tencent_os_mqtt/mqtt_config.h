#ifndef _TOS_MQTT_CONFIG_H_
#define  _TOS_MQTT_CONFIG_H_

#define MQTT_SERVER_IP       "106.13.99.157"  // "111.230.189.156"
#define MQTT_SERVER_PORT        "1883"
#define MQTT_PRODUCT_ID         "11KVANS7VO"
#define MQTT_DEV_NAME           "STM32"
#define MQTT_CLIENT_ID          "11KVANS7VOSTM32"
#define MQTT_USR_NAME           "11KVANS7VOSTM32;21010406;12365;4294967295"
#define MQTT_PASSWORD           "5f438cfe043cdf38748cb92d47c5a45ae45b8bd1;hmacsha1"
#define MQTT_SUBSCRIBE_TOPIC    "11KVANS7VO/STM32/ZX_control"
#define MQTT_PUBLISH_TOPIC      "11KVANS7VO/STM32/ZX_event"

#endif

