/*
 * File: SimulinkPIDNhietDoOutPWM.h
 *
 * Code generated for Simulink model 'SimulinkPIDNhietDoOutPWM'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Wed May 19 15:40:20 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SimulinkPIDNhietDoOutPWM_h_
#define RTW_HEADER_SimulinkPIDNhietDoOutPWM_h_
#include <float.h>
#include <string.h>
#include <stddef.h>
#ifndef SimulinkPIDNhietDoOutPWM_COMMON_INCLUDES_
# define SimulinkPIDNhietDoOutPWM_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_extmode.h"
#include "sysran_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "dt_info.h"
#include "ext_work.h"
#include "MW_PWM.h"
#include "MW_AnalogIn.h"
#endif                           /* SimulinkPIDNhietDoOutPWM_COMMON_INCLUDES_ */

#include "SimulinkPIDNhietDoOutPWM_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               (&(rtm)->Timing.taskTime0)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Fcn;                          /* '<S2>/Fcn' */
  real_T Constant;                     /* '<Root>/Constant' */
  real_T TmpRTBAtSumOutport1;          /* '<Root>/Sum' */
  real_T Saturation;                   /* '<S39>/Saturation' */
} B_SimulinkPIDNhietDoOutPWM_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  codertarget_arduinobase_int_h_T obj; /* '<Root>/Analog Input' */
  codertarget_arduinobase_inter_T obj_b;/* '<Root>/PWM' */
  e_codertarget_arduinobase_i_h_T gobj_0;/* '<Root>/Analog Input' */
  e_codertarget_arduinobase_i_h_T gobj_1;/* '<Root>/Analog Input' */
  e_codertarget_arduinobase_i_h_T gobj_2;/* '<Root>/Analog Input' */
  e_codertarget_arduinobase_i_h_T gobj_3;/* '<Root>/Analog Input' */
  e_codertarget_arduinobase_int_T gobj_0_g;/* '<Root>/PWM' */
  e_codertarget_arduinobase_int_T gobj_1_j;/* '<Root>/PWM' */
  e_codertarget_arduinobase_int_T gobj_2_g;/* '<Root>/PWM' */
  e_codertarget_arduinobase_int_T gobj_3_a;/* '<Root>/PWM' */
  real_T Integrator_DSTATE;            /* '<S32>/Integrator' */
  real_T Filter_DSTATE;                /* '<S27>/Filter' */
  real_T TmpRTBAtSumOutport1_Buffer0;  /* synthesized block */
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<Root>/Scope' */
} DW_SimulinkPIDNhietDoOutPWM_T;

/* Parameters (default storage) */
struct P_SimulinkPIDNhietDoOutPWM_T_ {
  real_T PIDController_D;              /* Mask Parameter: PIDController_D
                                        * Referenced by: '<S26>/Derivative Gain'
                                        */
  real_T PIDController_I;              /* Mask Parameter: PIDController_I
                                        * Referenced by: '<S29>/Integral Gain'
                                        */
  real_T PIDController_InitialConditionF;
                              /* Mask Parameter: PIDController_InitialConditionF
                               * Referenced by: '<S27>/Filter'
                               */
  real_T PIDController_InitialConditio_e;
                              /* Mask Parameter: PIDController_InitialConditio_e
                               * Referenced by: '<S32>/Integrator'
                               */
  real_T PIDController_Kb;             /* Mask Parameter: PIDController_Kb
                                        * Referenced by: '<S25>/Kb'
                                        */
  real_T PIDController_LowerSaturationLi;
                              /* Mask Parameter: PIDController_LowerSaturationLi
                               * Referenced by: '<S39>/Saturation'
                               */
  real_T PIDController_N;              /* Mask Parameter: PIDController_N
                                        * Referenced by: '<S35>/Filter Coefficient'
                                        */
  real_T PIDController_P;              /* Mask Parameter: PIDController_P
                                        * Referenced by: '<S37>/Proportional Gain'
                                        */
  real_T PIDController_UpperSaturationLi;
                              /* Mask Parameter: PIDController_UpperSaturationLi
                               * Referenced by: '<S39>/Saturation'
                               */
  real_T AnalogInput_SampleTime;       /* Expression: 1
                                        * Referenced by: '<Root>/Analog Input'
                                        */
  real_T Constant_Value;               /* Expression: 60
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T Integrator_gainval;           /* Computed Parameter: Integrator_gainval
                                        * Referenced by: '<S32>/Integrator'
                                        */
  real_T TmpRTBAtSumOutport1_InitialCond;/* Expression: 0
                                          * Referenced by: synthesized block
                                          */
  real_T Filter_gainval;               /* Computed Parameter: Filter_gainval
                                        * Referenced by: '<S27>/Filter'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_SimulinkPIDNhietDoOut_T {
  const char_T *errorStatus;
  RTWExtModeInfo *extModeInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    struct {
      boolean_T TID0_1;
    } RateInteraction;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_SimulinkPIDNhietDoOutPWM_T SimulinkPIDNhietDoOutPWM_P;

/* Block signals (default storage) */
extern B_SimulinkPIDNhietDoOutPWM_T SimulinkPIDNhietDoOutPWM_B;

/* Block states (default storage) */
extern DW_SimulinkPIDNhietDoOutPWM_T SimulinkPIDNhietDoOutPWM_DW;

/* External function called from main */
extern void SimulinkPIDNhietDoOutPWM_SetEventsForThisBaseStep(boolean_T
  *eventFlags);

/* Model entry point functions */
extern void SimulinkPIDNhietDoOutPWM_SetEventsForThisBaseStep(boolean_T
  *eventFlags);
extern void SimulinkPIDNhietDoOutPWM_initialize(void);
extern void SimulinkPIDNhietDoOutPWM_step0(void);
extern void SimulinkPIDNhietDoOutPWM_step1(void);
extern void SimulinkPIDNhietDoOutPWM_terminate(void);

/* Real-time Model object */
extern RT_MODEL_SimulinkPIDNhietDoOu_T *const SimulinkPIDNhietDoOutPWM_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SimulinkPIDNhietDoOutPWM'
 * '<S1>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller'
 * '<S2>'   : 'SimulinkPIDNhietDoOutPWM/Subsystem'
 * '<S3>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/Anti-windup'
 * '<S4>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/D Gain'
 * '<S5>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/Filter'
 * '<S6>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/Filter ICs'
 * '<S7>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/I Gain'
 * '<S8>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/Ideal P Gain'
 * '<S9>'   : 'SimulinkPIDNhietDoOutPWM/PID Controller/Ideal P Gain Fdbk'
 * '<S10>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Integrator'
 * '<S11>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Integrator ICs'
 * '<S12>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/N Copy'
 * '<S13>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/N Gain'
 * '<S14>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/P Copy'
 * '<S15>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Parallel P Gain'
 * '<S16>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Reset Signal'
 * '<S17>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Saturation'
 * '<S18>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Saturation Fdbk'
 * '<S19>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Sum'
 * '<S20>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Sum Fdbk'
 * '<S21>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Tracking Mode'
 * '<S22>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Tracking Mode Sum'
 * '<S23>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/postSat Signal'
 * '<S24>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/preSat Signal'
 * '<S25>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Anti-windup/Back Calculation'
 * '<S26>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/D Gain/Internal Parameters'
 * '<S27>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Filter/Disc. Forward Euler Filter'
 * '<S28>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Filter ICs/Internal IC - Filter'
 * '<S29>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/I Gain/Internal Parameters'
 * '<S30>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Ideal P Gain/Passthrough'
 * '<S31>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S32>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Integrator/Discrete'
 * '<S33>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Integrator ICs/Internal IC'
 * '<S34>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/N Copy/Disabled'
 * '<S35>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/N Gain/Internal Parameters'
 * '<S36>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/P Copy/Disabled'
 * '<S37>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Parallel P Gain/Internal Parameters'
 * '<S38>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Reset Signal/Disabled'
 * '<S39>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Saturation/Enabled'
 * '<S40>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Saturation Fdbk/Disabled'
 * '<S41>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Sum/Sum_PID'
 * '<S42>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Sum Fdbk/Disabled'
 * '<S43>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Tracking Mode/Disabled'
 * '<S44>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S45>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/postSat Signal/Forward_Path'
 * '<S46>'  : 'SimulinkPIDNhietDoOutPWM/PID Controller/preSat Signal/Forward_Path'
 */
#endif                              /* RTW_HEADER_SimulinkPIDNhietDoOutPWM_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
