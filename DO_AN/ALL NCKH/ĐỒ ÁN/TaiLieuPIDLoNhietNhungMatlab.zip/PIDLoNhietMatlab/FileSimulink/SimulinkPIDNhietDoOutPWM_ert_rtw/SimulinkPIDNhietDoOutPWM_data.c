/*
 * File: SimulinkPIDNhietDoOutPWM_data.c
 *
 * Code generated for Simulink model 'SimulinkPIDNhietDoOutPWM'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Wed May 19 15:40:20 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "SimulinkPIDNhietDoOutPWM.h"
#include "SimulinkPIDNhietDoOutPWM_private.h"

/* Block parameters (default storage) */
P_SimulinkPIDNhietDoOutPWM_T SimulinkPIDNhietDoOutPWM_P = {
  /* Mask Parameter: PIDController_D
   * Referenced by: '<S26>/Derivative Gain'
   */
  0.2,

  /* Mask Parameter: PIDController_I
   * Referenced by: '<S29>/Integral Gain'
   */
  0.4,

  /* Mask Parameter: PIDController_InitialConditionF
   * Referenced by: '<S27>/Filter'
   */
  0.0,

  /* Mask Parameter: PIDController_InitialConditio_e
   * Referenced by: '<S32>/Integrator'
   */
  0.0,

  /* Mask Parameter: PIDController_Kb
   * Referenced by: '<S25>/Kb'
   */
  1.0,

  /* Mask Parameter: PIDController_LowerSaturationLi
   * Referenced by: '<S39>/Saturation'
   */
  0.0,

  /* Mask Parameter: PIDController_N
   * Referenced by: '<S35>/Filter Coefficient'
   */
  100.0,

  /* Mask Parameter: PIDController_P
   * Referenced by: '<S37>/Proportional Gain'
   */
  13.0,

  /* Mask Parameter: PIDController_UpperSaturationLi
   * Referenced by: '<S39>/Saturation'
   */
  255.0,

  /* Expression: 1
   * Referenced by: '<Root>/Analog Input'
   */
  1.0,

  /* Expression: 60
   * Referenced by: '<Root>/Constant'
   */
  60.0,

  /* Computed Parameter: Integrator_gainval
   * Referenced by: '<S32>/Integrator'
   */
  0.01,

  /* Expression: 0
   * Referenced by: synthesized block
   */
  0.0,

  /* Computed Parameter: Filter_gainval
   * Referenced by: '<S27>/Filter'
   */
  0.01
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
