/*
 * File: SimulinkPIDNhietDoOutPWM_types.h
 *
 * Code generated for Simulink model 'SimulinkPIDNhietDoOutPWM'.
 *
 * Model version                  : 1.9
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Wed May 19 15:40:20 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_SimulinkPIDNhietDoOutPWM_types_h_
#define RTW_HEADER_SimulinkPIDNhietDoOutPWM_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Custom Type definition for MATLABSystem: '<Root>/Analog Input' */
#include "MW_SVD.h"
#ifndef typedef_b_cell_SimulinkPIDNhietDoOutP_T
#define typedef_b_cell_SimulinkPIDNhietDoOutP_T

typedef struct {
  char_T f1;
  char_T f2;
  char_T f3;
  char_T f4;
  char_T f5;
  char_T f6;
  char_T f7;
  char_T f8;
  char_T f9[2];
  char_T f10[2];
  char_T f11[2];
  char_T f12[2];
} b_cell_SimulinkPIDNhietDoOutP_T;

#endif                               /*typedef_b_cell_SimulinkPIDNhietDoOutP_T*/

#ifndef typedef_e_codertarget_arduinobase_int_T
#define typedef_e_codertarget_arduinobase_int_T

typedef struct {
  b_cell_SimulinkPIDNhietDoOutP_T AvailablePwmPinNames;
} e_codertarget_arduinobase_int_T;

#endif                               /*typedef_e_codertarget_arduinobase_int_T*/

#ifndef typedef_codertarget_arduinobase_inter_T
#define typedef_codertarget_arduinobase_inter_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  e_codertarget_arduinobase_int_T *Hw;
  MW_Handle_Type MW_PWM_HANDLE;
} codertarget_arduinobase_inter_T;

#endif                               /*typedef_codertarget_arduinobase_inter_T*/

#ifndef typedef_c_cell_SimulinkPIDNhietDoOutP_T
#define typedef_c_cell_SimulinkPIDNhietDoOutP_T

typedef struct {
  char_T f1;
  char_T f2;
  char_T f3;
  char_T f4;
  char_T f5;
  char_T f6;
  char_T f7;
  char_T f8;
  char_T f9[2];
  char_T f10[2];
  char_T f11[2];
  char_T f12[2];
} c_cell_SimulinkPIDNhietDoOutP_T;

#endif                               /*typedef_c_cell_SimulinkPIDNhietDoOutP_T*/

#ifndef typedef_e_codertarget_arduinobase_i_h_T
#define typedef_e_codertarget_arduinobase_i_h_T

typedef struct {
  c_cell_SimulinkPIDNhietDoOutP_T AvailablePwmPinNames;
} e_codertarget_arduinobase_i_h_T;

#endif                               /*typedef_e_codertarget_arduinobase_i_h_T*/

#ifndef typedef_codertarget_arduinobase_int_h_T
#define typedef_codertarget_arduinobase_int_h_T

typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  e_codertarget_arduinobase_i_h_T *Hw;
  MW_Handle_Type MW_ANALOGIN_HANDLE;
  real_T SampleTime;
} codertarget_arduinobase_int_h_T;

#endif                               /*typedef_codertarget_arduinobase_int_h_T*/

/* Parameters (default storage) */
typedef struct P_SimulinkPIDNhietDoOutPWM_T_ P_SimulinkPIDNhietDoOutPWM_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_SimulinkPIDNhietDoOut_T RT_MODEL_SimulinkPIDNhietDoOu_T;

#endif                        /* RTW_HEADER_SimulinkPIDNhietDoOutPWM_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
